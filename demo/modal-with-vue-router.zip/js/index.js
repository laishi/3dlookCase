var App = Vue.extend({});

var test = Vue.extend({
    template: '#test',
    
    data: {
        showModal: false
    }
});

var router = new VueRouter({});

router.map({
   '/':{
      component: test
   }
});

Vue.component('modal', {
  template: '#modal-template',
  props: ['show'],
  methods: {
    close: function () {
      this.show = false;
    },
    savePost: function () {
      this.close();
    }
  }
});

router.start(App, '#app');

/* new Vue({
  el: '#app',
  data: {
    showModal: false
  }
}); */
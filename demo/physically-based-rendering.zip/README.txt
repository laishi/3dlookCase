A Pen created at CodePen.io. You can find this one at http://codepen.io/playcanvas/pen/LENJxV.

 A rigid body simulation physically rendered in the PlayCanvas Engine. The code loads prefiltered cube maps and uses them to light the objects in the scene extremely realistically.
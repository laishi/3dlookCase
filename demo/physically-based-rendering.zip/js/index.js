// PHYSICALLY BASED RENDERING FUN!!!
// https://github.com/playcanvas/engine
var app, canvas;

// The texture images required by this demo
var server = 'http://static.playcanvas.com/';
var images = [];
for (var level = 0; level < 6; level++) {
  for (var face = 0; face < 6; face++) {
    images.push('cubemaps/hdr/grace/grace_m0' + level + '_c0' + face + '.png')
  }
}
images.push('textures/metal_d_1024.jpg');
images.push('textures/metal_met_1024.jpg');
images.push('textures/metal_g_1024.jpg');
images.push('textures/metal_n_1024.png');

var numLoaded = 0;

var cubeMaps = [];
var shapes = [];

function loadImage(i) {
  var image = new Image();
  image.crossOrigin = "anonymous";
  image.src = server + images[i];
  image.onload = function () {
    numLoaded++;
    if (numLoaded === images.length) {
      // We've got all the images - let's start!
      initialize();
    }
  };
  images[i] = image;
}

function loadImages() {
  for (var i = 0; i < images.length; i++) {
    loadImage(i);
  }
}

function createMaterial(d, s, g, n) {
  var mat = new pc.StandardMaterial();
  mat.shadingModel = pc.SPECULAR_BLINN;
  mat.diffuse.set(255/255, 203/255, 57/255);
  mat.diffuseMap = d;
  mat.specularMap = s;
  mat.glossMap = g;
  mat.normalMap = n;
  mat.shininess = 100;
  mat.conserveEnergy = true;
  mat.cubeMap = cubeMaps[0];
  mat.reflectivity = 1;
  mat.prefilteredCubeMap128 = cubeMaps[0];
  mat.prefilteredCubeMap64 = cubeMaps[1];
  mat.prefilteredCubeMap32 = cubeMaps[2];
  mat.prefilteredCubeMap16 = cubeMaps[3];
  mat.prefilteredCubeMap8 = cubeMaps[4];
  mat.prefilteredCubeMap4 = cubeMaps[5];
  mat.update();
  return mat;
}

function reset() {
  var counter = 0;
  for (var x = -2; x <= 2; x++) {
    for (var y = -2; y <= 2; y++) {
      for (var z = -2; z <= 2; z++) {
        counter++;
        shapes[counter].rigidbody.teleport(x, y, z, 0, 0, 0);
        shapes[counter].rigidbody.linearVelocity = pc.Vec3.ZERO;
        shapes[counter].rigidbody.angularVelocity = pc.Vec3.ZERO;
      }
    }
  }
}

function initialize() {
  // Create a PlayCanvas application
  canvas = document.getElementById("application-canvas");
  app = new pc.Application(canvas, {});
  app.start();

  // Fill the available space at full resolution
  app.setCanvasFillMode(pc.FILLMODE_FILL_WINDOW);
  app.setCanvasResolution(pc.RESOLUTION_AUTO);

  var camera = new pc.Entity();
  camera.addComponent('camera', {
    clearColor: new pc.Color(0, 0, 0),
    nearClip: 0.01,
    farClip: 10
  });
  app.root.addChild(camera);

  var light = new pc.Entity();
  light.addComponent('light', { type: 'point' });
  light.setPosition(2, 2, 2);
  app.root.addChild(light);

  var floor = new pc.Entity();
  floor.addComponent('model', {
    type: 'box'
  });
  floor.addComponent('collision', {
    type: 'box',
    halfExtents: new pc.Vec3(10, 0.1, 10)
  });
  floor.addComponent('rigidbody', {
    type: 'static'
  });
  app.root.addChild(floor);
  floor.rigidbody.teleport(0, -2.5, 0);
  
  var cube = new pc.Entity();
  cube.addComponent('model', {
    type: 'box'
  });
  cube.addComponent('collision', {
    type: 'box',
    halfExtents: new pc.Vec3(0.5, 0.5, 0.5)
  });
  cube.addComponent('rigidbody', {
    type: 'dynamic'
  });
  app.root.addChild(cube);

  var sphere = new pc.Entity();
  sphere.addComponent('model', {
    type: 'sphere'
  });
  sphere.addComponent('collision', {
    type: 'sphere'
  });
  sphere.addComponent('rigidbody', {
    type: 'dynamic'
  });
  app.root.addChild(sphere);

  for (var mip = 0; mip < 6; mip++) {
    var cubeMap = new pc.Texture(app.graphicsDevice, {
      cubemap: true,
      rgbm: true
    });
    cubeMap.setSource(images.slice(mip * 6, mip * 6 + 6));
    cubeMaps[mip] = cubeMap;
  }

  var metald = new pc.Texture(app.graphicsDevice);
  metald.setSource(images[36]);
  var metals = new pc.Texture(app.graphicsDevice);
  metals.setSource(images[37]);
  var metalg = new pc.Texture(app.graphicsDevice);
  metalg.setSource(images[38]);
  var metaln = new pc.Texture(app.graphicsDevice);
  metaln.setSource(images[39]);

  var metal = createMaterial(metald, metals, metalg, metaln);
  var chrome = createMaterial(null, null, null, null);
  
  cube.model.material = metal;
  sphere.model.material = chrome;

  var counter = 0;
  for (var x = -2; x <= 2; x++) {
    for (var y = -2; y <= 2; y++) {
      for (var z = -2; z <= 2; z++) {
        counter++;
        var e = (counter % 2) ? cube.clone() : sphere.clone();
        e.rigidbody.teleport(x, y, z, 0, 0, 0);
        app.root.addChild(e);
        shapes.push(e);
      }
    }
  }

  app.scene.skybox = cubeMaps[0];
  app.scene.toneMapping = pc.TONEMAP_FILMIC;
  app.scene.exposure = 2;
  
  // Register an update event to rotate the camera
  var timer = 0;
  app.on("update", function (dt) {
    timer += dt;
    camera.setPosition(0, 0, 0);
    camera.rotate(0, 20 * dt, 0);
    camera.translateLocal(0, 0, 5.5);
  });
  
  setInterval(reset, 5000);

  window.addEventListener('resize', function () {
    app.resizeCanvas(canvas.width, canvas.height);
  });
}

loadImages();
function fetchArray(key){
  if(sessionStorage.getItem(key)){
    return JSON.parse(sessionStorage.getItem(key));
  }
  return [];
}
function saveArray(key, value){
  sessionStorage.setItem(key, JSON.stringify(value));
}

new Vue({
  el: '#app',
  data: {
    newTodo: '',
    todos: fetchArray('todos')
  },

  ready: function(){
  this.$watch("todos", function(value){
    saveArray("todos", value);
  });
},

  methods: {
    addTodo: function () {
      var item= this.newTodo.trim();
      if (item) {
        this.todos.push({ item: item });
        this.newTodo = '';
      }
    },
		
    removeTodo: function (index) {
      this.todos.splice(index, 1);
    },
		removeAll: function (){
			this.todos = [];
		}
  }
});
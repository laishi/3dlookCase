A Pen created at CodePen.io. You can find this one at http://codepen.io/laishi/pen/OXVzEB.

 

Forked from [patrickkunka](http://codepen.io/patrickkunka/)'s Pen [[MixItUp] Getting Started](http://codepen.io/patrickkunka/pen/KisAG/).
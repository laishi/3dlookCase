A Pen created at CodePen.io. You can find this one at http://codepen.io/koenigsegg1/pen/EyVgpK.

 I needed to brush up on my flexbox skills, so I created this little pen. The tabs aren't functional (yet), but the menu, input, and profile have some cool interactions.

Check it out on your mobile device here: http://s.codepen.io/koenigsegg1/debug/EyVgpK.
<img src="http://koenigsegg1.netne.net/img/Mobile.png" alt="Mobile View" />
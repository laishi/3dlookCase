A Pen created at CodePen.io. You can find this one at http://codepen.io/IamSwap/pen/VLqaKE.

 Basic Vue Router Example using Official Vue Router plugin

Libraries used
Vuejs : http://vuejs.org/
Vue-Router: https://github.com/vuejs/vue-router/
